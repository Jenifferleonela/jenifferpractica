<?php
$peso= $_POST["peso"];
$estatura= $_POST["estatura"];
 echo " la estatura es: .$peso. " "

?>