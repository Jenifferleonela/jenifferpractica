
function calcularIMC() {
    let peso = document.getElementById("peso").value;
    let estatura = document.getElementById("estatura").value;
    
    // Asegúrate de convertir a números flotantes y realizar la operación correcta
    let imc = parseFloat(peso) / (parseFloat(estatura) * parseFloat(estatura));

    if (imc < 18.5) {
        document.getElementById("resultado").innerHTML = "Su índice de masa corporal es bajo: " + imc.toFixed(2);
    } else if (imc >= 18.5 && imc <= 24.9) {
        document.getElementById("resultado").innerHTML = "Su índice de masa corporal es saludable: " + imc.toFixed(2);
    } else if (imc >= 25 && imc <= 29.9) {
        document.getElementById("resultado").innerHTML = "Su índice de masa corporal es sobrepeso: " + imc.toFixed(2);
    } else if (imc >= 30 && imc <= 34.9) {
        document.getElementById("resultado").innerHTML = "Su índice de masa corporal es obesidad I: " + imc.toFixed(2);
    } else if (imc >= 35 && imc <= 39.9) {
        document.getElementById("resultado").innerHTML = "Su índice de masa corporal es obesidad II: " + imc.toFixed(2);
    } else {
        document.getElementById("resultado").innerHTML = "Su índice de masa corporal es obesidad III: " + imc.toFixed(2);
    }
}
